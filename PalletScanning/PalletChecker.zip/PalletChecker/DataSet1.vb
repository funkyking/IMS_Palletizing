﻿Partial Class DataSet1

End Class
