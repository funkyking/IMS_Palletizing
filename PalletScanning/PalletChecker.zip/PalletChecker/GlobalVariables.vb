﻿Public Class GlobalVariables
    Public Shared AdminAccess As Boolean = False
    Public Shared LoginInstance As frmLogin = Nothing
End Class
